<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Module 1 - ICT 4561 - Eric Zorn</title>
</head>
<body>

<?php

    echo phpinfo()

?>


<script></script>
</body>
</html>