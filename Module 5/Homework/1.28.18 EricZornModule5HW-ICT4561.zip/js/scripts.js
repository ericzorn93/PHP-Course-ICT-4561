// Eric Zorn - ICT 4561: Module 5 - JS Scripts - 1/28/2018

const fullyLoaded = "The page is loaded correctly";
alert(fullyLoaded);