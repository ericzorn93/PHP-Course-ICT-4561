<?php
/**
 * Index Page.
 * User: ericzorn
 * Date: 1/28/18
 * Time: 12:38 PM
 */

// Importing Page Opening/Beginning
require("inc/page-begin.php");

?>

<h1 class="title">ICT 4561: Module 5 - Modular Design - Eric Zorn - 1/28/2018</h1>


<p class="info">
    So far, in this course, I have learned a lot about PHP. In this assignment, it is very helpful to learn how includes
    and requiring information works. The reason for this being so useful, is the ability to build dynamic websites based
    off of a modular or component like structure. This allows the developer to create navigation, footers, sidebars,
    links, or any other HTML element only once. After the element has been developed and designed, the developer would
    then be able import that component onto any other pages throughout the entire website or web application.
</p>

<p class="info">
    These components can be reused over and over again throughout the entire site, due to the fact that they are getting
    rendered and imported where they are specified over the server. Theoretically, if the developer wanted to create
    identical navigation bars and include them on the same page, he or she would only need to write the code for this
    navigation bar into a single file. This file would then be placed into the component folder. He or she can use the
    PHP include or require functions to be able to import that component multiple times into their code on any web pages.
</p>

<p class="info">
    <em>
    ** In order to use the proper styles from an external CSS document, I would recommend saving them into a CSS folder
    on the server/in your root folder. This way, you can link to those CSS documents within any module if it is necessary.
    </em>
</p>




<img src="img/php-image.jpg" alt="PHP Image Logo">


<script src="js/scripts.js"></script>

<?php
// Importing Page Closing/Ending
require("inc/page-end.php");
?>