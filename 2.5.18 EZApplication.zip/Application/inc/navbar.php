<?php
/**
 * Created by PhpStorm.
 * User: ericzorn
 * Date: 2/4/18
 * Time: 9:18 AM
 */

?>

<!-- As a heading -->
<nav class="navbar navbar-light bg-light">
    <span class="navbar-brand mb-0 h1">ICT 4561 - Application - Eric Zorn</span>
</nav>